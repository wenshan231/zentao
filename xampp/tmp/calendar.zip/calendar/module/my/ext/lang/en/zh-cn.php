﻿<?php
//add by huang
$lang->my->todocalendar='我的TODO日历视图';
$lang->my->ajaxGetTodo = '接口:获取TODO';
$lang->my->todocalendar='TODO日历视图';
$lang->my->todocalendarpriv='请在权限分组中设置权限';